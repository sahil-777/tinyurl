exports.getmd5 = (longURL) => {
    return longURL;
}