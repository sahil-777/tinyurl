const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
// const {
//     getmd5
// } = require('./npm-md5.js');

const getmd5 = require('md5')

exports.handler = async (event, context, callback) => {
    // Captures the requestId from the context message
    //let requestId = context.awsRequestId;
    let longURL = 'https://www.google.com/';
    // Handle promise fulfilled/rejected states
    await createMessage(longURL).then(() => {
        callback(null, {
            statusCode: 201,
            body: JSON.stringify(JSON.parse(event.body))
        });
    }).catch((err) => {
        console.error(err);
    });
};

function createMessage(longURL) {
    const params = {
        TableName: 'urlMapper',
        Item: {
            'shortURLkey': getmd5(longURL),
            'longURL': longURL
        }
    };
    return ddb.put(params).promise();
}

